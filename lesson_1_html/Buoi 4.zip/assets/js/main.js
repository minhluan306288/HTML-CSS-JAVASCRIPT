function handleClosePopup(){
    var popup =  document.getElementById('popup-get-email-x2398')
    if(popup){
        popup.setAttribute('style', 'display: none')
    }
}